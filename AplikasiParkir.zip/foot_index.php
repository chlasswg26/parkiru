    <!-- Start XP Footerbar -->
        <div class="xp-footerbar">
            <footer class="footer">
                <p class="mb-0">Copyright ChlassWG © 2019</p>
            </footer>
        </div>
        <!-- End XP Footerbar -->


        </div>
        <!-- End XP Rightbar -->

    </div>
    <!-- End XP Container -->